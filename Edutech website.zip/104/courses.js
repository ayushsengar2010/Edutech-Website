// Script File

// Toggle Module Details
function toggleDetails(moduleNumber) {
    const details = document.getElementById(`details-${moduleNumber}`);
    if (details.style.display === "none" || details.style.display === "") {
        details.style.display = "block";
        const nestedLists = details.querySelectorAll('ul ul');
        nestedLists.forEach(list => list.style.display = 'block');
    } else {
        details.style.display = "none";
        const nestedLists = details.querySelectorAll('ul ul');
        nestedLists.forEach(list => list.style.display = 'none');
    }
}


  

// Recomandation start
document.addEventListener("DOMContentLoaded", function() {
    const showMoreBtn = document.querySelector(".show-more-btn");
    showMoreBtn.addEventListener("click", function() {
        // Add logic to show more courses or load more content
        alert("Show more courses functionality to be implemented.");
    });
});
// recamondation end

// Testimonials Section Starts
$('.reviews-slider').owlCarousel({
    loop:true,
    autoplay:true,
    autoplayTimeout:6000,
    margin:10,
    nav:true,
    navText:["<i class='fa-solid fa-arrow-left'></i>",
             "<i class='fa-solid fa-arrow-right'></i>"],
    responsive:{
        0:{
            items:1
        },
        768:{
            items:2
        }
    }
})
// Testimonials Section Ends

$('.teachers-slider').owlCarousel({
  loop:true,
  autoplay:true,
  autoplayTimeout:6000,
  margin:10,
  nav:true,
  navText:["<i class='fa-solid fa-arrow-left'></i>",
           "<i class='fa-solid fa-arrow-right'></i>"],
  responsive:{
      0:{
          items:1
      },
      768:{
          items:2
      }
  }
})



