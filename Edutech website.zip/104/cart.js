document.addEventListener('DOMContentLoaded', function () {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
  
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function () {
            const courseId = this.getAttribute('data-course-id');
            const courseCard = this.closest('.course-card');
            const courseInfo = {
                id: courseId,
                title: courseCard.querySelector('.course-title').innerText,
                videos: courseCard.querySelector('.course-desc span:nth-child(1)').innerText,
                students: courseCard.querySelector('.course-desc span:nth-child(2)').innerText,
                rating: courseCard.querySelector('.course-ratings span:nth-child(1)').innerText,
                price: courseCard.querySelector('.course-ratings span:nth-child(2)').innerText,
                image: courseCard.querySelector('img').src,
                quantity: 1 // Set initial quantity to 1
            };
  
            let cart = JSON.parse(localStorage.getItem('cart')) || [];

            const existingCourseIndex = cart.findIndex(item => item.id === courseId);

            if (existingCourseIndex !== -1) {
                // If course already exists, increase its quantity
                cart[existingCourseIndex].quantity += 1;
            } else {
                // If course does not exist, add it to the cart
                cart.push(courseInfo);
            }

            localStorage.setItem('cart', JSON.stringify(cart));
            window.location.href = 'cart.html';
        });
    });
});
